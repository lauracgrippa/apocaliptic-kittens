# Origem dos arquivos

- Bibliotecas GLFW, GLAD, GLM, tinyobjloader, stb_image, malha `sphere.obj` e estrutura de compilação: `computer-graphics-project.zip`, fornecido pelo usuário, base da disciplina INF01047/UFRGS.
- Malha `cube.obj`: `Computacao-Grafica.zip`, fornecido pelo usuário, originada dos laboratórios da disciplina.
- `brick.jpg`: `red_brick_diff_1k.jpg` — https://polyhaven.com/a/red_brick
- `ground.jpg`: `rocky_terrain_02_diff_1k.jpg` — https://polyhaven.com/a/rocky_terrain_02
- `src/preview.cpp`, shaders `preview.vert` e `preview.frag`: código elaborado para este protótipo.
