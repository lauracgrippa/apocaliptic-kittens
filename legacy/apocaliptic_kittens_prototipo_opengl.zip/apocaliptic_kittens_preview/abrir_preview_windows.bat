@echo off
setlocal
where cmake >nul 2>&1 || (echo Instale CMake primeiro. & pause & exit /b 1)
cmake -S "%~dp0" -B "%~dp0build" || (pause & exit /b 1)
cmake --build "%~dp0build" --config Release || (pause & exit /b 1)
cd /d "%~dp0"
if exist "build\Release\apocaliptic_preview.exe" (
  "build\Release\apocaliptic_preview.exe" --demo
) else (
  "build\apocaliptic_preview.exe" --demo
)
pause
