# Apocaliptic Kittens — protótipo de caminhada

Protótipo executável e intencionalmente pequeno, **sem engine de jogo**, baseado nas bibliotecas incluídas no ZIP da disciplina (C++17, OpenGL 3.3, GLFW, GLAD, GLM e tinyobjloader).

## O que faz

- Teodora, uma gata laranja modelada provisoriamente com primitivas low-poly, caminha e corre com animação de patas e cauda.
- Três Chads de modelos provisórios patrulham pequenos trajetos entre pontos predefinidos.
- Cenário simplificado inspirado nas edificações e caminhos do Campus do Vale, com texturas de terreno e tijolos do ZIP original.
- Terceira pessoa seguindo Teodora, com modo órbita e zoom.
- Movimentação e animações independentes da taxa de quadros via `deltaTime`.
- Reutilização das mesmas malhas OBJ (esfera do pacote da disciplina e cubo do pacote de Computação Gráfica) com transformações de escala, rotação e posição diferentes.

**Ainda não implementado:** IA de perseguição/ataque, drone Bézier, Betinhas, resgates, vidas, colisões com paredes, Churus que restauram vida e estados de fase. São elementos previstos na especificação final, não neste protótipo.

**Importante:** os ZIPs de código fornecidos não incluíam os modelos 3D definitivos de Teodora, Chads, Betinhas ou Campus do Vale. Os modelos deste protótipo são representações temporárias de malhas simples. Não são equivalentes aos modelos finalizados do jogo.

## Compilar (Windows / MSYS2 UCRT64)

Instale CMake, Ninja, gcc/g++ e os pacotes necessários para compilar pelo terminal UCRT64 do MSYS2. A biblioteca estática GLFW está incluída no ZIP.

```bash
cmake -S . -B build -G Ninja
cmake --build build
./build/apocaliptic_preview.exe
```

Se usar Visual Studio no Windows:

```powershell
cmake -S . -B build -G "Visual Studio 17 2022" -A x64
cmake --build build --config Release
.\build\Release\apocaliptic_preview.exe
```

## Compilar (Linux)

Precisa de CMake, compilador C++, bibliotecas de desenvolvimento OpenGL/X11 e Threads.

```bash
cmake -S . -B build
cmake --build build -j
./build/apocaliptic_preview
```

**Execute a partir do diretório que contém a pasta `assets`** (por exemplo, na raiz do projeto). Os assets também são copiados para a pasta do executável após a compilação.

## Teclas e mouse

| Ação | Comando |
| --- | --- |
| Caminhar | W A S D |
| Correr | Shift + W A S D |
| Alternar câmera fixa / órbita | C |
| Girar a câmera | Segurar botão direito do mouse e arrastar |
| Zoom | Roda do mouse |
| Reiniciar Teodora | R |
| Sair | Esc |

## Estrutura

- `src/preview.cpp`: protótipo com entidades, atualização, câmera e desenho.
- `src/glad.c`, `src/tiny_obj_loader.cpp`, `src/stb_image.cpp`: bibliotecas do projeto enviado.
- `include`, `lib-*`: headers e bibliotecas GLFW fornecidos no ZIP da disciplina.
- `assets/models`: as malhas primitivas `sphere.obj` e `cube.obj`.
- `assets/textures`: duas texturas do ZIP da disciplina, com fontes indicadas em `ATTRIBUTION.md`.
- `assets/shaders`: shaders OpenGL 3.3 com iluminação ambiente, difusa e especular.

## Demonstração automática

Se quiser **ver Teodora caminhando sem segurar W**, execute:

```bash
./build/apocaliptic_preview --demo
```

Na demonstração, os controles W A S D continuam disponíveis e assumem temporariamente o movimento quando pressionados.

## Modo de teste

Para renderizar exatamente 2 quadros e encerrar (útil para testar a inicialização):

```bash
./build/apocaliptic_preview --frames 2 --capture teste.ppm
```

O arquivo PPM é opcional; qualquer visualizador de imagens ou ferramenta de conversão pode abri-lo.
